<script lang="ts">
	import { page } from '$app/state';

	// TODO Phase 4 : brancher sur GET /verifier/:token (endpoint public,
	// sans authentification) et afficher les 3 cas : valide / annulé /
	// introuvable. Placeholder ci-dessous pour valider le routage.
	const token = page.params.token;
</script>

<div class="flex min-h-screen items-center justify-center bg-slate-50 px-4">
	<div class="w-full max-w-md rounded-xl bg-white p-8 text-center shadow-sm">
		<h1 class="text-lg font-semibold text-slate-900">Vérification de document</h1>
		<p class="mt-2 text-sm text-slate-500">
			Token reçu : <code class="rounded bg-slate-100 px-1.5 py-0.5">{token}</code>
		</p>
		<p class="mt-4 text-sm text-slate-400">
			À implémenter en Phase 4 — voir docs/PLAN.md et SPEC.md §4.5.
		</p>
	</div>
</div>
