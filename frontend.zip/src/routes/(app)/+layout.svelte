<script lang="ts">
	import { onMount } from 'svelte';
	import { goto } from '$app/navigation';
	import { page } from '$app/state';
	import { resolve } from '$app/paths';
	import Logo from '$lib/components/Logo.svelte';
	import Icon from '$lib/components/Icon.svelte';
	import { monter } from '$lib/motion';
	import { session } from '$lib/stores/session.svelte';

	let { children } = $props();

	const liensNav = [
		{ href: resolve('/tableau-de-bord'), label: 'Tableau de bord' },
		{ href: resolve('/eleves'), label: 'Élèves' },
		{ href: resolve('/documents'), label: 'Documents' },
		{ href: resolve('/archives'), label: 'Archives' },
		{ href: resolve('/parametres'), label: 'Paramètres' }
	];

	// Garde d'authentification : si aucun accessToken en mémoire, on tente une
	// restauration silencieuse via le refresh token stocké (§8) avant de
	// rediriger vers /connexion. `verifie` évite un flash du contenu protégé
	// pendant cette vérification.
	let verifie = $state(false);

	onMount(async () => {
		if (!session.estConnecte && !(await session.tenterRestauration())) {
			await goto(resolve('/connexion'));
			return;
		}
		verifie = true;
	});

	function initiales(nomComplet: string): string {
		const mots = nomComplet.trim().split(/\s+/);
		return ((mots[0]?.[0] ?? '') + (mots[1]?.[0] ?? '')).toUpperCase();
	}

	const initialesCompte = $derived(
		session.utilisateur ? initiales(session.utilisateur.nomComplet) : ''
	);
	const libelleCompte = $derived(
		session.utilisateur && session.etablissement
			? `Compte : ${session.utilisateur.fonction}, ${session.etablissement.nom}`
			: ''
	);

	// Placeholder simple en attendant une maquette dédiée pour le menu compte.
	async function seDeconnecter() {
		if (!confirm('Se déconnecter ?')) return;
		session.effacer();
		await goto(resolve('/connexion'));
	}

	let menuOuvert = $state(false);

	function fermerMenu() {
		menuOuvert = false;
	}

	// Le CSS du menu mobile (voir design-system.css) cible `body.menu-open`
	// pour afficher le panneau de nav et le scrim par-dessus toute la page.
	$effect(() => {
		document.body.classList.toggle('menu-open', menuOuvert);
	});
</script>

<svelte:window
	onkeydown={(e) => {
		if (e.key === 'Escape') fermerMenu();
	}}
/>

{#if verifie}
	<header class="topbar">
		<a class="brand" href={resolve('/tableau-de-bord')} aria-label="Scoly, accueil">
			<Logo height={40} />
		</a>
		<nav class="nav" id="nav" aria-label="Navigation principale">
			{#each liensNav as lien (lien.href)}
				<a
					href={lien.href}
					aria-current={page.url.pathname.startsWith(lien.href) ? 'page' : undefined}
					onclick={fermerMenu}
				>
					{lien.label}
				</a>
			{/each}
		</nav>
		<div class="actions">
			<button class="round" aria-label="Notifications">
				<Icon name="bell" />
				<span class="dot"></span>
			</button>
			<button
				class="avatar"
				aria-label={`${libelleCompte} — se déconnecter`}
				onclick={seDeconnecter}
			>
				{initialesCompte}
			</button>
			<button
				class="round menu-btn"
				aria-label={menuOuvert ? 'Fermer le menu' : 'Ouvrir le menu'}
				aria-expanded={menuOuvert}
				aria-controls="nav"
				onclick={() => (menuOuvert = !menuOuvert)}
			>
				<Icon name={menuOuvert ? 'close' : 'menu'} />
			</button>
		</div>
	</header>

	<div class="shell">
		<div class="scrim" role="presentation" onclick={fermerMenu}></div>
		<main class="app-main">
			<!-- Clé = chemin seul : changer de page rejoue l'entrée, pas les paramètres d'URL (?q=, ?eleve=). -->
			{#key page.url.pathname}
				<div in:monter={{ y: 8 }}>
					{@render children()}
				</div>
			{/key}
		</main>
	</div>
{/if}

<style>
	/* `.avatar` sert maintenant de bouton de déconnexion, en attendant une
	   vraie maquette de menu compte : on ne garde que le style visuel
	   existant, sans le padding/bordure par défaut d'un <button>. */
	.avatar {
		padding: 0;
		cursor: pointer;
	}
</style>
