
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/(app)" | "/" | "/(app)/archives" | "/conditions-d-utilisation" | "/connexion" | "/creer-un-compte" | "/(app)/documents" | "/(app)/eleves" | "/invitation" | "/(app)/parametres" | "/politique-de-confidentialite" | "/(app)/tableau-de-bord" | "/verifier" | "/verifier/[token]";
		RouteParams(): {
			"/verifier/[token]": { token: string }
		};
		LayoutParams(): {
			"/(app)": Record<string, never>;
			"/": { token?: string | undefined };
			"/(app)/archives": Record<string, never>;
			"/conditions-d-utilisation": Record<string, never>;
			"/connexion": Record<string, never>;
			"/creer-un-compte": Record<string, never>;
			"/(app)/documents": Record<string, never>;
			"/(app)/eleves": Record<string, never>;
			"/invitation": Record<string, never>;
			"/(app)/parametres": Record<string, never>;
			"/politique-de-confidentialite": Record<string, never>;
			"/(app)/tableau-de-bord": Record<string, never>;
			"/verifier": { token?: string | undefined };
			"/verifier/[token]": { token: string }
		};
		Pathname(): "/" | "/archives" | "/conditions-d-utilisation" | "/connexion" | "/creer-un-compte" | "/documents" | "/eleves" | "/invitation" | "/parametres" | "/politique-de-confidentialite" | "/tableau-de-bord" | "/verifier" | `/verifier/${string}` & {};
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}